- Trabalho Avaliativo para conclusão de matéria | POO Em Java
* Projeto em linguagem Java que cria um Sistema de cadastro.



* Para tudo funcionar corretamente utilize as informações abaixo como base:

SGBD utilizado: Mysql

* Nome da Database: gestao_venda
* Porta: localhost

 - Estar utilizando a IDE Netbeans e certificar que tem o JDBC instalado na máquina.

* Todo o código foi testado antes de ser postado no Github.

------

Universidade Estácio de Sá
##
Programação Orientada a Objetos em Java